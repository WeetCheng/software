﻿$xl = [Runtime.InteropServices.Marshal]::GetActiveObject('Excel.Application')
$target_range = $xl.Selection().Address()
$null = [System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl)
Out-Host -InputObject $target_range